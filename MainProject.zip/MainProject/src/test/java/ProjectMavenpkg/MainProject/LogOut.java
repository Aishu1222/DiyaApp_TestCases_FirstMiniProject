package ProjectMavenpkg.MainProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class LogOut
{ 
	WebDriver wb;
  @Test
  public void logoutfunction(WebDriver wb, String un, String pass) 
  {
	 try 
	 {
		 wb.findElement(By.linkText("Logout")).click();
	 }
	 catch(Exception e)
	 {
		 System.out.println("Invalid Data with: "+un+"    "+pass );
	 }
  }
}
