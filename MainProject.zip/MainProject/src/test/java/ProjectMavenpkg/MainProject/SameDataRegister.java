package ProjectMavenpkg.MainProject;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SameDataRegister 
{ 
	WebDriver wb;
  @Test
  public void same_data() throws IOException
  {
	    FileInputStream file1 = new FileInputStream("C:\\Users\\AISHAWARYA\\eclipse-workspace\\MainProject\\ProjectMaven.xlsx");
		XSSFWorkbook book1 = new XSSFWorkbook(file1);
	    XSSFSheet sh = book1.getSheet("registerdata");
	   
    // wb.findElement(By.linkText("REGISTER")).click();
     int row = sh.getLastRowNum();
     System.out.println(row);
     for(int i=1;i<=row; i++)
	  	    {   wb.findElement(By.linkText("REGISTER")).click();
		    	String fname=sh.getRow(i).getCell(0).toString();
			  	String lname=sh.getRow(i).getCell(1).toString();
			  	String phno=sh.getRow(i).getCell(2).toString();
			  	String email=sh.getRow(i).getCell(3).toString();
			  	String addr=sh.getRow(i).getCell(4).toString();
			  	String city=sh.getRow(i).getCell(5).toString();
			  	String state=sh.getRow(i).getCell(6).toString();
			  	String postalcode=sh.getRow(i).getCell(7).toString();
			  	String country=sh.getRow(i).getCell(8).toString();
			  	String un=sh.getRow(i).getCell(9).toString();
			  	String pass=sh.getRow(i).getCell(10).toString();
			  	String cpass=sh.getRow(i).getCell(11).toString();
			  	
			  	
			  
			  	wb.findElement(By.name("firstName")).sendKeys(fname);
				wb.findElement(By.name("lastName")).sendKeys(lname);
				wb.findElement(By.name("phone")).sendKeys(phno);
				wb.findElement(By.id("userName")).sendKeys(email);
				wb.findElement(By.name("address1")).sendKeys(addr);
				wb.findElement(By.name("city")).sendKeys(city);
				wb.findElement(By.name("state")).sendKeys(state);
				wb.findElement(By.name("postalCode")).sendKeys(postalcode);
				wb.findElement(By.name("country")).sendKeys(country);
			 
				wb.findElement(By.id("email")).sendKeys(un);
				wb.findElement(By.name("password")).sendKeys(pass);
				wb.findElement(By.name("confirmPassword")).sendKeys(cpass);
				wb.findElement(By.name("submit")).click();
		 
		  	for(int j=i+1;j<=row; j++)
			  	  {  
				    	String fname1=sh.getRow(j).getCell(0).toString();
					  	String lname1=sh.getRow(j).getCell(1).toString();
					  	String phno1=sh.getRow(j).getCell(2).toString();
					  	String email1=sh.getRow(j).getCell(3).toString();
					  	String addr1=sh.getRow(j).getCell(4).toString();
					  	String city1=sh.getRow(j).getCell(5).toString();
					  	String state1=sh.getRow(j).getCell(6).toString();
					  	String postalcode1=sh.getRow(j).getCell(7).toString();
					  	String country1=sh.getRow(j).getCell(8).toString();
					  	String un1=sh.getRow(j).getCell(9).toString();
					  	String pass1=sh.getRow(j).getCell(10).toString();
					  	String cpass1=sh.getRow(j).getCell(11).toString();
					  	
					  	
					  	
			  	  
			 if(fname==fname1 && lname==lname1 && phno==phno1 && email==email1 && addr==addr1 && city==city1 && state==state1 && postalcode==postalcode1 && country==country1 && un==un1 && pass==pass1 && cpass==cpass1)
			   	{
			  		System.out.println("same data" +i +" and " +j);
			  		System.out.println("already register");
			   	}
			else if(phno==phno1) 
				{ 
		  		System.out.println("Already registered Phone number use another  " +phno +"   " +fname+" "+lname);
		  		}
			else if(email==email1) 
		  		{ 
		  		System.out.println("Already registered email id use another  " +email);
		  		}
			else if(un==un1 && pass==pass1 && cpass==cpass1)
			  	{
			  	System.out.println("already register");
			  	}
				
		   	  }
		  	
			  	  }
		  	
	  	  }
	  	  	  	
	  	    
  
  @BeforeTest
  public void setting()
  {
  	System.setProperty("webdriver.chrome.driver", "F:\\Drivers\\chromedriver_win32\\chromedriver.exe");
  	wb = new ChromeDriver();
  	wb.get("http://demo.guru99.com/test/newtours");
  	wb.manage().window().maximize();
  	  
  }

  @AfterTest
  public void afterTest()
  {
  }

}
