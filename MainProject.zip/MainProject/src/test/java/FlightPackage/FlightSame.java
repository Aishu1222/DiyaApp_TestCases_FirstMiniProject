package FlightPackage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class FlightSame {
WebDriver wb;
	
	public static void PerformFlight(WebDriver wb, String p, String dept_f, String  f_m, String f_d, String dept_t, String t_m, String t_d, String air) 
	  {
		WebElement flight = wb.findElement(By.linkText("Flights"));
		flight.click();
		WebElement type1 =  wb.findElement(By.cssSelector("input[Value='roundtrip']"));
		WebElement type2 =  wb.findElement(By.cssSelector("input[Value='oneway']"));
		Scanner s1 = new Scanner(System.in);
		System.out.println("Eneter 1 for roundTrip :"+"\n"+"Eneter 2 for onewayTrip:");
		int a = s1.nextInt();
		
		switch(a)
		{
		case 1: 
				type1.click(); 		
				if(type1.isSelected())
				{
			    System.out.println("You selected roundTrip");
				}
			    break;
				
				
		case 2: 			    
				type2.click(); 
				if(type2.isSelected())
				{
					System.out.println("You selected onewayTrip");
				}
				break;
				
		 default:
			 System.out.println("Invalid Choice");
			 break;
		}
		
		Select passenger = new Select(wb.findElement(By.name("passCount")));
		passenger.selectByVisibleText(p);
		
		Select dept_from = new Select(wb.findElement(By.name("fromPort")));
		dept_from.selectByVisibleText(dept_f);
		Select from_m = new Select(wb.findElement(By.name("fromMonth")));
		from_m.selectByVisibleText(f_m);
		Select from_d = new Select(wb.findElement(By.name("fromDay")));
		from_d.selectByVisibleText(f_d);
		
		Select dept_to = new Select(wb.findElement(By.name("toPort")));
		dept_to.selectByVisibleText(dept_t);
		Select to_month = new Select(wb.findElement(By.name("toMonth")));
		to_month.selectByVisibleText(t_m);
		Select to_day = new Select(wb.findElement(By.name("toDay")));
		to_day.selectByVisibleText(t_d);
		
		WebElement service1 = wb.findElement(By.cssSelector("input[Value='Coach']"));
		WebElement service2 = wb.findElement(By.cssSelector("input[Value='Business']"));
		WebElement service3 = wb.findElement(By.cssSelector("input[Value='First']"));
		
		
		Scanner s2 = new Scanner(System.in);
		System.out.println("Eneter 1 for Economy class :"+"\n"+"Eneter 2 for Business class:"+"\n"+"Eneter 3 for First class:");
		int b= s2.nextInt();
		
		switch(b)
		{
		case 1: 
			    service1.click(); 		
				if(service1.isSelected())
				{
			    System.out.println("You selected Economy class");
				}
			    break;
				
				
		case 2: 			    
			    service2.click(); 
				if(service2.isSelected())
				{
					System.out.println("You selected Business class");
				}
				break;
				
		case 3: 			    
				service3.click(); 
				if(service3.isSelected())
				{
					System.out.println("You selected First class");
				}
				break;
				
		 default:
			 System.out.println("Invalid Choice");
			 break;
		}
		
		
		
		Select airlines = new Select(wb.findElement(By.name("airline")));
		airlines.selectByVisibleText(air);
		WebElement continue_btn = wb.findElement(By.name("findFlights"));
		continue_btn.click();
		
		  if(dept_f==dept_t && wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/reservation2.php"))
			{
			  System.out.println("Test Failed with same destination and arriving");
			}
			else if(f_m==t_m && f_d==t_d && wb.getCurrentUrl().equalsIgnoreCase("http://demo.guru99.com/test/newtours/reservation2.php"))
			{
				System.out.println("Test Failed with same date");
			}
			else
			{
				System.out.println("Test Passed");
			}
		
		
	  }
  @Test
  public void f() throws IOException
  {
	  FileInputStream file = new FileInputStream("C:\\Users\\AISHAWARYA\\eclipse-workspace\\MainProject\\ProjectMaven.xlsx");
	  XSSFWorkbook book = new XSSFWorkbook(file);
	  XSSFSheet sh = book.getSheet("sameflight");
	  
	  for(int i=1;i<=sh.getLastRowNum(); i++)
	  	 {
		  		 String p = sh.getRow(i).getCell(0).toString();
		  		 String dept_f = sh.getRow(i).getCell(1).toString();
		  		 String f_m = sh.getRow(i).getCell(2).toString();
		  		 String f_d = sh.getRow(i).getCell(3).toString();
		  		 String dept_t = sh.getRow(i).getCell(4).toString();
		  		 String t_m = sh.getRow(i).getCell(5).toString();
		  		String t_d = sh.getRow(i).getCell(6).toString();
		  		 String air = sh.getRow(i).getCell(7).toString();
		  		 
		  		FlightSame.PerformFlight(wb,p,dept_f, f_m,f_d,dept_t,t_m,t_d, air);	 
	 
	  	 }
	  
	
	  
	  
  }
  @BeforeTest
  public void beforeTest()
  {
	  System.setProperty("webdriver.chrome.driver", "F:\\Drivers\\chromedriver_win32\\chromedriver.exe");
	  wb = new ChromeDriver();
	  wb.navigate().to("http://demo.guru99.com/test/newtours/index.php");
	  wb.manage().window().maximize();
  }

  @AfterTest
  public void afterTest()
  {
	  wb.close();
  }

}
