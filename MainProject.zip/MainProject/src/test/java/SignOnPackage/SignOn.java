package SignOnPackage;

import org.testng.annotations.Test;

import LoginPackage.LoginPage;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SignOn {

	   WebDriver wb;
		
		
public static void performSignOn(WebDriver wb, String username, String password )
  {
	        WebElement sign_on = wb.findElement(By.linkText("SIGN-ON"));	
	        sign_on.click();
	        WebElement login_id = wb.findElement(By.name("userName"));
			login_id.sendKeys(username);
			WebElement login_pass = wb.findElement(By.name("password"));
			login_pass.sendKeys(password);
			WebElement login_btn = wb.findElement(By.name("submit"));
			login_btn.click();	
	
   }
		

@Test
public void  signOn() throws IOException, InterruptedException
{  
		FileInputStream file1 = new FileInputStream("C:\\Users\\AISHAWARYA\\eclipse-workspace\\MainProject\\ProjectMaven.xlsx");
		XSSFWorkbook book1 = new XSSFWorkbook(file1);
		XSSFSheet sh = book1.getSheet("logindata");
		XSSFSheet sh1 = book1.getSheet("InvalidLogin");
		System.out.println("Total No. of Credentials: "  + sh.getLastRowNum());

for(int i=1;i<=sh.getLastRowNum(); i++)
{
	 String username = sh.getRow(i).getCell(0).toString();
	 String password = sh.getRow(i).getCell(1).toString();
	 
	 SignOn.performSignOn(wb,username,password);
	
	 System.out.println(username+" "+password);	
	
	
	if(wb.getTitle().equalsIgnoreCase("Login: Mercury Tours"))
	 {
		 System.out.println("Test passed");
	 }
	 else 
	 {
		 System.out.println("Test Failed");
	 }

}


for(int i=1;i<=sh1.getLastRowNum(); i++)
{   
	 wb.get("http://demo.guru99.com/test/newtours/index.php");
	
	 
	 String username = sh1.getRow(i).getCell(0).toString();
	 String password = sh1.getRow(i).getCell(1).toString();
	 
	 SignOn.performSignOn(wb,username,password);
	
     System.out.println(username+" "+password);	
  
	
	if(wb.getTitle().equalsIgnoreCase("Login: Mercury Tours"))
	 {
		 System.out.println("Test Failed For Invalid Data   " +i);
	 }
	 else 
	 { 
		 System.out.println("Test Passed for Invalid Data   " +i);
	 }
}


}

@BeforeTest
public void  before()
  {
		System.setProperty("webdriver.chrome.driver", "F:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		wb = new ChromeDriver();
		wb.get("http://demo.guru99.com/test/newtours");
		wb.manage().window().maximize();  
  }

@AfterTest
public void  after()
  {
		wb.close();
		
  }

}
